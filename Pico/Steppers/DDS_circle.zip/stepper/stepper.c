
/**
 * V. Hunter Adams
 * vha3@cornell.edu
 * September, 2021
*/

#include "motor_library.h"
#include <math.h>

#define MOTOR1_IN1 2
#define MOTOR2_IN1 6

#define convert(a) (unsigned int)(125000000./(Fs*(float)a))

//DDS parameters
#define two32 4294967296.0 // 2^32 
#define Fs 50.0

// the DDS units:
volatile unsigned int phase_accum_main;
volatile unsigned int phase_incr_main = (unsigned int)((.03125*two32)/Fs) ;

// DDS sine table
#define sine_table_size 256
volatile float sin_table[sine_table_size] ;

// Variables to hold motor speed
volatile unsigned int motorspeed = 125000;
volatile unsigned int motorspeed2 = 125000 ;

// Variables to track motor direction
volatile int direction = 1 ;
volatile int old_direction = 1 ;
volatile int direction2 = 1 ;
volatile int old_direction2 = 1 ;

// Delay variables
volatile int delay1 = 0 ;
volatile int delay2 = 0 ;

// Sine table values
volatile float sineval ;
volatile float sineval2 ;

// Speed values
volatile float speed ;
volatile float speed2 ;

// Motor directions
unsigned int motor1_direction ;
unsigned int motor2_direction ;

float sigma = 10.0 ;
float beta = 2.6667 ;
float rho = 28.0 ;
volatile float x1 = -1.0 ;
volatile float x2 = 0.1 ;
volatile float x3 = 25.0 ;
volatile float dx1 ;
volatile float dx2 ;
volatile float dx3 ;
float dt = 0.0002 ;

bool repeating_timer_callback(struct repeating_timer *t) {

    // dx1 = sigma * (x2-x1) ;
    // dx2 = x1*(rho-x3) - x2 ;
    // dx3 = x1*x2 - beta*x3 ;

    // x1 = x1 + dt*dx1 ;
    // x2 = x2 + dt*dx2 ;
    // x3 = x3 + dt*dx3 ;

    // motor2_direction = (dx1>0) ? CLOCKWISE : COUNTERCLOCKWISE  ;
    // motor1_direction = (dx3>0) ? CLOCKWISE : COUNTERCLOCKWISE ;

    // direction2 = (dx1>0) ? 1 : 0 ;
    // direction = (dx3>0) ? 1 : 0 ;

    // SET_DIRECTION_MOTOR_1(motor1_direction) ;
    // SET_DIRECTION_MOTOR_2(motor2_direction) ;

    // speed2 = (dx1>0) ? .09*dx1:-.09*dx1 ;
    // speed = (dx3>0) ? .09*dx3:-.09*dx3 ;

    // if (direction != old_direction) {
    //     old_direction = direction ;
    //     delay1 = 15 ;
    // }

    // if (direction2 != old_direction2) {
    //     old_direction2 = direction2 ;
    //     delay2 = 15 ;
    // }

    // motorspeed = convert(speed) ;
    // motorspeed2 = convert(speed2) ;

    // if (motorspeed > 6250000) {
    //     SET_DIRECTION_MOTOR_1(STOPPED) ;
    //     motorspeed = 6250000 ;
    // }
    // if (motorspeed2 > 6250000) {
    //     SET_DIRECTION_MOTOR_2(STOPPED) ;
    //     motorspeed2 = 6250000 ;
    // }

    // if (!delay1) {
    //     SET_SPEED_MOTOR_1(motorspeed) ;
    // }
    // else {
    //     SET_SPEED_MOTOR_1(125000) ;
    //     delay1 -= 1 ;
    // }
    // if (!delay2) {
    //     SET_SPEED_MOTOR_2(motorspeed2) ;
    // }
    // else {
    //     delay2 -= 1 ;
    //     SET_SPEED_MOTOR_2(125000) ;
    // }

    





    // DDS phase and sine table lookup
    phase_accum_main += phase_incr_main  ;

    sineval = sin_table[phase_accum_main >> 24] ;
    sineval2 = sin_table[((phase_accum_main + 1073741824) >> 24)] ;

    motor1_direction = (sineval>0) ? CLOCKWISE : COUNTERCLOCKWISE  ;
    motor2_direction = (sineval2>0) ? CLOCKWISE : COUNTERCLOCKWISE ;

    direction = (sineval>0) ? 1 : 0 ;
    direction2 = (sineval2>0) ? 1 : 0 ;

    SET_DIRECTION_MOTOR_1(motor1_direction) ;
    SET_DIRECTION_MOTOR_2(motor2_direction) ;

    speed = (sineval>0) ? sineval:-sineval ;
    speed2 = (sineval2>0) ? sineval2:-sineval2 ;

    motorspeed = convert(speed) ;
    motorspeed2 = convert(speed2) ;

    ////////////

    if (direction != old_direction) {
        old_direction = direction ;
        delay1 = 10 ;
    }

    if (direction2 != old_direction2) {
        old_direction2 = direction2 ;
        delay2 = 10 ;
    }

    if (motorspeed > 6250000) {
        SET_DIRECTION_MOTOR_1(STOPPED) ;
        motorspeed = 6250000 ;
    }
    if (motorspeed2 > 6250000) {
        SET_DIRECTION_MOTOR_2(STOPPED) ;
        motorspeed2 = 6250000 ;
    }

    if (!delay1) {
        SET_SPEED_MOTOR_1(motorspeed) ;
    }
    else {
        SET_SPEED_MOTOR_1(125000) ;
        delay1 -= 1 ;
    }
    if (!delay2) {
        SET_SPEED_MOTOR_2(motorspeed2) ;
    }
    else {
        delay2 -= 1 ;
        SET_SPEED_MOTOR_2(125000) ;
    }

    // SET_SPEED_MOTOR_1(motorspeed) ;
    // SET_SPEED_MOTOR_2(motorspeed2) ;

    return true;
}

void pio0_interrupt_handler() {
    pio_interrupt_clear(pio_0, 0) ;
    MOVE_STEPS_MOTOR_1(0xFFFFFFFF) ;
}

void pio1_interrupt_handler() {
    pio_interrupt_clear(pio_1, 0) ;
    MOVE_STEPS_MOTOR_2(0xFFFFFFFF) ;
}

int main() {
    stdio_init_all();

    // Setup each motor
    setupMotor1(MOTOR1_IN1, pio0_interrupt_handler) ;
    setupMotor2(MOTOR2_IN1, pio1_interrupt_handler) ;

    // === build the sine lookup table =======
    // scaled to produce values between 0 and 4096
    int ii;
    for (ii = 0; ii < sine_table_size; ii++){
         sin_table[ii] = (int)((20.*sin((float)ii*6.283/(float)sine_table_size)));
    }

    // Create a repeating timer that calls repeating_timer_callback.
    struct repeating_timer timer;

    // Negative delay so means we will call repeating_timer_callback, and call it again
    // 50ms (20 Hz) later regardless of how long the callback took to execute
    add_repeating_timer_ms(-20, repeating_timer_callback, NULL, &timer);
    
    // Call the interrupt handlers
    pio1_interrupt_handler() ;
    pio0_interrupt_handler() ;

    while (true) {
    }
}
